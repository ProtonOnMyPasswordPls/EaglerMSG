package net.eaglermsg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import net.lax1dude.eaglercraft.backend.server.api.IEaglerPlayer;
import net.lax1dude.eaglercraft.backend.server.api.IEaglerXServerAPI;
import net.lax1dude.eaglercraft.backend.server.api.bukkit.EaglerXServerAPI;
import net.lax1dude.eaglercraft.backend.server.api.notifications.EnumBadgePriority;
import net.lax1dude.eaglercraft.backend.server.api.notifications.INotificationBuilder;
import net.lax1dude.eaglercraft.backend.server.api.notifications.INotificationService;

public final class EaglerMsg extends JavaPlugin {
    private static final String PREFIX = "&8[&bEaglerMsg&8] &7";
    private static final int NOTIFICATION_EXPIRE_AFTER = 10800000;

    private IEaglerXServerAPI<Player> eaglerAPI;
    private INotificationService<Player> notificationService;
    private final Map<Player, Player> lastMessages = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();

        eaglerAPI = EaglerXServerAPI.instance();
        notificationService = eaglerAPI.getNotificationService();

        CommandHandler handler = new CommandHandler();

        if (getCommand("eaglermsg") != null) {
            getCommand("eaglermsg").setExecutor(handler);
            getCommand("eaglermsg").setTabCompleter(handler);
        }

        if (getCommand("eaglerreply") != null) {
            getCommand("eaglerreply").setExecutor(handler);
            getCommand("eaglerreply").setTabCompleter(handler);
        }

        getLogger().info("EaglerMsg enabled.");
    }

    @Override
    public void onDisable() {
        lastMessages.clear();
        getLogger().info("EaglerMsg disabled.");
    }

    private String color(String text) {
        if (text == null) {
            return "";
        }

        return ChatColor.translateAlternateColorCodes('&', text);
    }

    private String message(String path) {
        return color(getConfig().getString(path, ""));
    }

    private String prefixedMessage(String path) {
        return color(PREFIX) + message(path);
    }

    private String getPermission(String path, String fallback) {
        return getConfig().getString(path, fallback);
    }

    private Player findPlayer(String name) {
        if (name == null) {
            return null;
        }

        for (Player player : getServer().getOnlinePlayers()) {
            if (player.getName().equalsIgnoreCase(name)) {
                return player;
            }
        }

        return null;
    }

    private IEaglerPlayer<Player> getEaglerPlayer(Player player) {
        if (player == null) {
            return null;
        }

        return eaglerAPI.getEaglerPlayer(player);
    }

    private boolean isEaglerPlayer(Player player) {
        return getEaglerPlayer(player) != null;
    }

    private EnumBadgePriority parsePriority(String value) {
        if (value == null) {
            return EnumBadgePriority.NORMAL;
        }

        try {
            return EnumBadgePriority.valueOf(
                    value.trim().toUpperCase(Locale.ROOT)
            );
        } catch (IllegalArgumentException exception) {
            getLogger().warning(
                    "Invalid notification priority '" + value
                            + "'. Using NORMAL."
            );
            return EnumBadgePriority.NORMAL;
        }
    }

    private Integer parseColor(String value, int fallback) {
        if (value == null) {
            return fallback;
        }

        String input = value.trim();

        if (input.startsWith("#")) {
            input = input.substring(1);
        }

        if (input.startsWith("0x") || input.startsWith("0X")) {
            input = input.substring(2);
        }

        if (input.length() != 6) {
            return fallback;
        }

        try {
            return Integer.parseInt(input, 16) & 0xFFFFFF;
        } catch (NumberFormatException exception) {
            return fallback;
        }
    }

    private void reloadPluginConfig() {
        reloadConfig();
        eaglerAPI = EaglerXServerAPI.instance();
        notificationService = eaglerAPI.getNotificationService();
    }

    private void sendNotification(
            IEaglerPlayer<Player> recipient,
            Player sender,
            String body
    ) {
        if (recipient == null) {
            return;
        }

        Class<?> componentType = eaglerAPI.getComponentTypes()
                .stream()
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "EaglerXServer did not expose a component type."
                ));

        @SuppressWarnings("unchecked")
        INotificationBuilder<Object> builder =
                (INotificationBuilder<Object>) notificationService
                        .createNotificationBuilder(
                                (Class<Object>) componentType
                        );

        String title = color("&bPrivate Message");
        String source = color("&7" + sender.getName());

        int background = parseColor(
                getConfig().getString(
                        "settings.notification.background",
                        "#202020"
                ),
                0x202020
        );

        int titleColor = parseColor(
                getConfig().getString(
                        "settings.notification.title-color",
                        "#FFFFFF"
                ),
                0xFFFFFF
        );

        int bodyColor = parseColor(
                getConfig().getString(
                        "settings.notification.body-color",
                        "#FFFFFF"
                ),
                0xFFFFFF
        );

        int sourceColor = parseColor(
                getConfig().getString(
                        "settings.notification.source-color",
                        "#AAAAAA"
                ),
                0xAAAAAA
        );

        EnumBadgePriority priority = parsePriority(
                getConfig().getString(
                        "settings.notification.priority",
                        "NORMAL"
                )
        );

        boolean silent = getConfig().getBoolean(
                "settings.notification.silent",
                false
        );

        int hideAfter = getConfig().getInt(
                "settings.notification.hide-after",
                10
        );

        int configuredExpireAfter = getConfig().getInt(
                "settings.notification.expire-after",
                -1
        );

        int expireAfter = configuredExpireAfter == -1
                ? NOTIFICATION_EXPIRE_AFTER
                : configuredExpireAfter;

        builder
                .setBadgeUUIDRandom()
                .setTitleComponent(title)
                .setBodyComponent(color(body))
                .setSourceComponent(source)
                .setPriority(priority)
                .setSilent(silent)
                .setHideAfterSec(hideAfter)
                .setExpireAfterSec(expireAfter)
                .setBackgroundColor(background)
                .setTitleTxtColorRGB(titleColor)
                .setBodyTxtColorRGB(bodyColor)
                .setSourceTxtColorRGB(sourceColor);

        recipient.getNotificationManager().showNotificationBadge(builder);
    }

    private boolean sendMessage(
            CommandSender sender,
            Player target,
            String message
    ) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(prefixedMessage("messages.player-only"));
            return true;
        }

        Player senderPlayer = (Player) sender;

        if (!isEaglerPlayer(senderPlayer)) {
            sender.sendMessage(prefixedMessage("messages.java-player"));
            return true;
        }

        if (!isEaglerPlayer(target)) {
            sender.sendMessage(prefixedMessage("messages.player-not-found"));
            return true;
        }

        if (target.equals(senderPlayer)) {
            sender.sendMessage(
                    prefixedMessage("messages.cannot-message-self")
            );
            return true;
        }

        sendNotification(
                getEaglerPlayer(target),
                senderPlayer,
                message
        );

        lastMessages.put(senderPlayer, target);
        lastMessages.put(target, senderPlayer);

        sender.sendMessage(
                prefixedMessage("messages.message-sent")
                        .replace("%player%", target.getName())
        );

        return true;
    }

    private boolean handleMessage(
            CommandSender sender,
            String[] args
    ) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(prefixedMessage("messages.player-only"));
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage(prefixedMessage("messages.usage-message"));
            return true;
        }

        Player senderPlayer = (Player) sender;

        if (!isEaglerPlayer(senderPlayer)) {
            sender.sendMessage(prefixedMessage("messages.java-player"));
            return true;
        }

        Player target = findPlayer(args[0]);

        if (target == null || !isEaglerPlayer(target)) {
            sender.sendMessage(
                    prefixedMessage("messages.player-not-found")
            );
            return true;
        }

        StringBuilder message = new StringBuilder();

        for (int i = 1; i < args.length; i++) {
            if (message.length() > 0) {
                message.append(' ');
            }

            message.append(args[i]);
        }

        return sendMessage(sender, target, message.toString());
    }

    private boolean handleReply(
            CommandSender sender,
            String[] args
    ) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(prefixedMessage("messages.player-only"));
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(prefixedMessage("messages.usage-reply"));
            return true;
        }

        Player senderPlayer = (Player) sender;

        if (!isEaglerPlayer(senderPlayer)) {
            sender.sendMessage(prefixedMessage("messages.java-player"));
            return true;
        }

        Player target = lastMessages.get(senderPlayer);

        if (target == null
                || !target.isOnline()
                || !isEaglerPlayer(target)) {
            sender.sendMessage(prefixedMessage("messages.no-reply"));
            return true;
        }

        StringBuilder message = new StringBuilder();

        for (String argument : args) {
            if (message.length() > 0) {
                message.append(' ');
            }

            message.append(argument);
        }

        return sendMessage(sender, target, message.toString());
    }

    private boolean handleReload(CommandSender sender) {
        if (!sender.hasPermission(getPermission(
                "settings.permissions.reload",
                "eaglermsg.reload"
        ))) {
            sender.sendMessage(prefixedMessage("messages.no-permission"));
            return true;
        }

        reloadPluginConfig();

        sender.sendMessage(prefixedMessage("messages.reload"));
        return true;
    }

    private final class CommandHandler
            implements CommandExecutor, TabCompleter {

        @Override
        public boolean onCommand(
                CommandSender sender,
                Command command,
                String label,
                String[] args
        ) {
            String name = command.getName().toLowerCase(Locale.ROOT);

            if (name.equals("eaglermsg")) {
                if (args.length > 0
                        && args[0].equalsIgnoreCase("reload")) {
                    return handleReload(sender);
                }

                if (!sender.hasPermission(getPermission(
                        "settings.permissions.message",
                        "eaglermsg.message"
                ))) {
                    sender.sendMessage(
                            prefixedMessage("messages.no-permission")
                    );
                    return true;
                }

                return handleMessage(sender, args);
            }

            if (name.equals("eaglerreply")) {
                if (!sender.hasPermission(getPermission(
                        "settings.permissions.reply",
                        "eaglermsg.reply"
                ))) {
                    sender.sendMessage(
                            prefixedMessage("messages.no-permission")
                    );
                    return true;
                }

                return handleReply(sender, args);
            }

            return true;
        }

        @Override
        public List<String> onTabComplete(
                CommandSender sender,
                Command command,
                String alias,
                String[] args
        ) {
            String name = command.getName().toLowerCase(Locale.ROOT);

            if (name.equals("eaglermsg")) {
                if (args.length == 1) {
                    String input = args[0].toLowerCase(Locale.ROOT);
                    List<String> result = new ArrayList<>();

                    if (sender.hasPermission(getPermission(
                            "settings.permissions.reload",
                            "eaglermsg.reload"
                    )) && "reload".startsWith(input)) {
                        result.add("reload");
                    }

                    if (sender.hasPermission(getPermission(
                            "settings.permissions.message",
                            "eaglermsg.message"
                    ))) {
                        for (IEaglerPlayer<Player> eaglerPlayer :
                                eaglerAPI.getAllEaglerPlayers()) {

                            Player player =
                                    eaglerPlayer.getPlayerObject();

                            if (player == null || !player.isOnline()) {
                                continue;
                            }

                            if (player.getName()
                                    .toLowerCase(Locale.ROOT)
                                    .startsWith(input)) {
                                result.add(player.getName());
                            }
                        }
                    }

                    Collections.sort(result);
                    return result;
                }

                if (args.length >= 2
                        && args[0].equalsIgnoreCase("reload")) {
                    return Collections.emptyList();
                }

                return Collections.emptyList();
            }

            if (name.equals("eaglerreply")) {
                if (!sender.hasPermission(getPermission(
                        "settings.permissions.reply",
                        "eaglermsg.reply"
                ))) {
                    return Collections.emptyList();
                }

                return Collections.emptyList();
            }

            return Collections.emptyList();
        }
    }
}